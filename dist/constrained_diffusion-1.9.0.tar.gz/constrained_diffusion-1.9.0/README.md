

# Constrained diffusion decomposition: A new PDE-based image decomposition method

This project performs constrained diffusion decomposition numpy.ndarray data, decomposing it into scale-based components. It is designed for astronomical image processing and uses the `astropy` and `scipy` libraries.

### Input:

numpy nd array, of shape e.g. (nx, ny, nz)

### Output:

result: numpy nd array, of shape (m, nx, ny, nz). The mth commponent contain structures of sizes 2$^(m-1)$ to 2$^m$ pixels. residual: numpy nd array, of shape (nx, ny, nz) the input data will be recovered as input = sum_i result[i] + residual

### Usage:

### (a) under the shell,
```sh
constrained_diffusion_decomposition input.fits
```

the output file will be named as input.fits_scale.fits

### (b) inside python
```python
import constrained_diffusion_decomposition as cdd

result, residual = cdd.constrained_diffusion_decomposition(data)
```

An <a href="https://github.com/gxli/Constrained-Diffusion-Decomposition/blob/main/example.ipynb"> example </a> is avaliable here

### How it is done:

Assuuming an input of I(x, y),t he decomposition is achieved by solving the equation

```math
\frac{\partial I_t }{\partial t} ={\rm sgn}(I_t) \mathcal{H}({- \rm sgn}(I_t) \nabla^2 I_t) \nabla^2 I_t ;,
```
where t is related to the scale l by t = l**2
 

  
  
References: 

<a href="https://arxiv.org/abs/2201.05484"> Li 2022, Multi-Scale Decomposition of Astronomical Maps -- Constrained Diffusion Method </a>

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/constrained_diffusion.git
   cd constrained_diffusion
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Install the package:
   ```bash
   pip install .
   ```

## Usage

Run the decomposition on a FITS file:
```bash
constrained_diffusion_decomposition <fits_file>
```

This will process the input FITS file and save the scale decomposition to `<fits_file>_scale.fits`.

To use the module in Python code:
```python
from constrained_diffusion.constrained_diffusion_decomposition import constrained_diffusion_decomposition
# Use the function as needed
```

## Project Structure

- `src/`: Source code and tests
  - `constrained_diffusion_decomposition.py`: Core constrained diffusion decomposition function
  - `main.py`: Command-line interface for processing FITS files
- `requirements.txt`: Project dependencies

## Dependencies

- Python 3.6+
- astropy>=5.0
- numpy>=1.20
- scipy>=1.7
- pytest>=7.0 (for testing)


## License
 See the [LICENSE](LICENSE) file for details.
